<?php
return array(
	'No matches found' => 'Brak wyników szukania',
	'Please enter {chars} more characters' => 'Proszę wprowadzić jeszcze {chars} znaków',
	'You can only select {count} items' => 'Można wybrac tylko {count} pozycji',
	'Loading more results...' => 'Ładowanie pozostałych wyników',
	'Searching...' => 'Szukanie...',
);
