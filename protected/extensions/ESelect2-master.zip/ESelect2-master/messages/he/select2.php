<?php
/**
 * @author Yakir Sitbon <http://www.yakirs.net/>
 */
return array(
	'No matches found' => 'לא נמצאו תוצאות',
	'Please enter {chars} more characters' => 'אנא הזן עוד {chars} תווים',
	'Please enter {chars} less characters' => 'אנא מחק {chars} תווים',
	'You can only select {count} items' => 'אתה יכול לצפות ב-{count} רשומות בלבד',
	'Loading more results...' => 'טוען עוד תוצאות...',
	'Searching...' => 'מחפש...',
);
