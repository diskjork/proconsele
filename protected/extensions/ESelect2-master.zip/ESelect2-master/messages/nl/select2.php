<?php
return array(
	'No matches found' => 'Niets gevonden',
	'Please enter {chars} more characters' => 'Nog {chars} extra karakter(s) vereist',
	'Please enter {chars} less characters' => 'Nog {chars} karakter(s) te veel',
	'You can only select {count} items' => 'Je kunt maar {count} items selecteren',
	'Loading more results...' => 'Meer resultaten aan het laden...',
	'Searching...' => 'Aan het zoeken...',
);
