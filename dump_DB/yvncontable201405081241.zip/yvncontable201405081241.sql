-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-05-2014 a las 17:41:36
-- Versión del servidor: 5.6.11
-- Versión de PHP: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `yvncontable`
--
CREATE DATABASE IF NOT EXISTS `yvncontable` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `yvncontable`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `idarea` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`idarea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asiento`
--

CREATE TABLE IF NOT EXISTS `asiento` (
  `idasiento` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `descripcion` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `cuenta_idcuenta` int(11) NOT NULL,
  `subcuenta_idsubcuenta` int(11) NOT NULL,
  PRIMARY KEY (`idasiento`),
  KEY `fk_asiento_cuenta2_idx` (`cuenta_idcuenta`),
  KEY `fk_asiento_subcuenta1_idx` (`subcuenta_idsubcuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `authassignment`
--

CREATE TABLE IF NOT EXISTS `authassignment` (
  `itemname` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `userid` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `bizrule` text COLLATE utf8_spanish_ci,
  `data` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `authitem`
--

CREATE TABLE IF NOT EXISTS `authitem` (
  `name` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_spanish_ci,
  `bizrule` text COLLATE utf8_spanish_ci,
  `data` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `authitemchild`
--

CREATE TABLE IF NOT EXISTS `authitemchild` (
  `parent` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `banco`
--

CREATE TABLE IF NOT EXISTS `banco` (
  `idBanco` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` bigint(20) DEFAULT NULL,
  `direccion` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `propio` int(11) DEFAULT NULL,
  `localidad_idlocalidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`idBanco`),
  KEY `fk_banco_localidad1_idx` (`localidad_idlocalidad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja`
--

CREATE TABLE IF NOT EXISTS `caja` (
  `idcaja` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuenta_idcuenta` int(11) NOT NULL,
  PRIMARY KEY (`idcaja`),
  KEY `fk_caja_cuenta1_idx` (`cuenta_idcuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cheque`
--

CREATE TABLE IF NOT EXISTS `cheque` (
  `idcheque` int(11) NOT NULL AUTO_INCREMENT,
  `nrocheque` bigint(20) NOT NULL,
  `titular` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `cuittitular` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fechaingreso` date NOT NULL,
  `fechacobro` date NOT NULL,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `debeohaber` tinyint(1) NOT NULL COMMENT 'debehaber se lo utiliza para diferenciar si el cheque de debita o se acredita',
  `estado` bit(3) NOT NULL,
  `banco_idBanco` int(11) NOT NULL,
  `proveedor_idproveedor` int(11) DEFAULT NULL,
  `cliente_idcliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`idcheque`),
  KEY `fk_cheque_banco1_idx` (`banco_idBanco`),
  KEY `fk_cheque_proveedor1_idx` (`proveedor_idproveedor`),
  KEY `fk_cheque_cliente1_idx` (`cliente_idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `idcliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `cuit` varchar(13) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombrecontacto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `web` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `localidad_idlocalidad` int(11) NOT NULL,
  `tipocontribuyente_idtipocontribuyente` int(11) NOT NULL,
  PRIMARY KEY (`idcliente`),
  KEY `fk_cliente_localidad1_idx` (`localidad_idlocalidad`),
  KEY `fk_cliente_tipocontribuyente1_idx` (`tipocontribuyente_idtipocontribuyente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cobranza`
--

CREATE TABLE IF NOT EXISTS `cobranza` (
  `idcobranza` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `descripcioncobranza` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `importe` double NOT NULL,
  `ctactecliente_idctactecliente` int(11) NOT NULL,
  PRIMARY KEY (`idcobranza`),
  KEY `fk_cobranza_ctactecliente1_idx` (`ctactecliente_idctactecliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ctabancaria`
--

CREATE TABLE IF NOT EXISTS `ctabancaria` (
  `idctabancaria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  `banco_idBanco` int(11) NOT NULL,
  `tipoctabancaria_idtipoctabancaria` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL COMMENT 'Para diferenciar si la cuenta bancaria está en uso o no.',
  PRIMARY KEY (`idctabancaria`),
  KEY `fk_ctabancaria_banco1_idx` (`banco_idBanco`),
  KEY `fk_ctabancaria_tipoctabancaria1_idx` (`tipoctabancaria_idtipoctabancaria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ctactecliente`
--

CREATE TABLE IF NOT EXISTS `ctactecliente` (
  `idctactecliente` int(11) NOT NULL AUTO_INCREMENT,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `saldo` double DEFAULT NULL,
  `cliente_idcliente` int(11) NOT NULL,
  PRIMARY KEY (`idctactecliente`),
  KEY `fk_ctactecliente_cliente1_idx` (`cliente_idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ctacteprov`
--

CREATE TABLE IF NOT EXISTS `ctacteprov` (
  `idctacteprov` int(11) NOT NULL AUTO_INCREMENT,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `saldo` double DEFAULT NULL,
  `proveedor_idproveedor` int(11) NOT NULL,
  PRIMARY KEY (`idctacteprov`),
  KEY `fk_ctacteprov_proveedor1_idx` (`proveedor_idproveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuenta`
--

CREATE TABLE IF NOT EXISTS `cuenta` (
  `idcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `codigocta` varchar(45) CHARACTER SET utf8 NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tipocuenta_idtipocuenta` int(11) NOT NULL,
  `asentable` tinyint(1) NOT NULL,
  PRIMARY KEY (`idcuenta`),
  KEY `fk_cuenta_tipocuenta1_idx` (`tipocuenta_idtipocuenta`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=158 ;

--
-- Volcado de datos para la tabla `cuenta`
--

INSERT INTO `cuenta` (`idcuenta`, `codigocta`, `nombre`, `tipocuenta_idtipocuenta`, `asentable`) VALUES
(2, '110000', 'ACTIVO CORRIENTE ', 2, 0),
(3, '111000', 'CAJA Y BANCOS', 2, 0),
(4, '111100', 'Caja ', 2, 1),
(5, '111300', 'Banco Regional - ch/ pago dif. ', 2, 1),
(6, '111400', 'Banco Regional - 285/7 ', 2, 1),
(7, '111500', 'Banco Galicia c/c', 2, 1),
(8, '111600', 'Banco Nación C/A ', 2, 1),
(9, '111700', 'Galiciac/c ', 2, 1),
(10, '112000', 'CREDITOS POR VENTAS', 2, 0),
(11, '112100', 'Deudores por Ventas', 2, 1),
(12, '113000', 'OTROS CREDITOS ', 2, 0),
(13, '113100', 'Iva - Crédito Fiscal ', 2, 1),
(14, '113200', 'Ret. y Percep. de IVA', 2, 1),
(15, '113300', 'Ret. y Percep. de Imp. Gcias.', 2, 1),
(16, '113400', 'Gcia Mín. Presunta S/F ', 2, 1),
(17, '113450', 'Ant. Imp. Gcia. Mín. Presunta', 2, 1),
(18, '113500', 'Imp. a las GciasS/F', 2, 1),
(19, '113600', 'Ret. Contrib. Patronales ', 2, 1),
(20, '113700', 'Ret. Imp. Ingresos Brutos', 2, 1),
(21, '113800', 'Perc. Imp. deb/cred. bancarios ', 2, 1),
(22, '113900', 'IVA - saldo Libre Disponib ', 2, 1),
(23, '114000', 'IVA - Saldo a Favor 1er Párr ', 2, 1),
(24, '114001', 'BIENES DE CAMBIO ', 2, 0),
(25, '114100', 'Materia Prima', 2, 1),
(26, '114200', 'Productos Terminados ', 2, 1),
(27, '114300', 'Insumos', 2, 1),
(28, '115000', 'OTROS ACTIVOS', 2, 0),
(29, '115100', 'José - Cta. Particular ', 2, 1),
(30, '115200', 'Jorge - Cta. Particular', 2, 1),
(31, '115300', 'Alberto - Cta. Particular', 2, 1),
(32, '115400', 'Dora Arizu - Cta. Particular ', 2, 1),
(33, '115500', 'Mónica - Cta. Particular ', 2, 1),
(34, '120000', 'ACTIVO NO CORRIENTE', 3, 0),
(35, '121000', 'BIENES DE USO', 3, 0),
(36, '121010', 'Muebles y Utiles ', 3, 1),
(37, '121020', 'Amort. acum. Muebles y Utiles', 3, 1),
(38, '121030', 'Máquinas y Herramientas', 3, 1),
(39, '121040', 'Amort. Acum. Máq. y Herram.', 3, 1),
(40, '121070', 'Rodados', 3, 1),
(41, '121080', 'Amort. Acum. Rodados ', 3, 1),
(42, '121090', 'Inmuebles', 3, 1),
(43, '121100', 'Amort. Acum. Inmuebles ', 3, 1),
(44, '121110', 'Inmuebles - en Construcción', 3, 1),
(46, '210000', 'PASIVO CORRIENTE ', 4, 0),
(47, '211000', 'CUENTAS POR PAGAR', 4, 0),
(48, '211100', 'Proveedores compras varias ', 4, 1),
(49, '211300', 'Documentos a Pagar ', 4, 1),
(50, '211500', 'Argencard', 4, 1),
(51, '213000', 'DEUDAS FISCALES', 4, 0),
(52, '213110', 'IVA a Pagar', 4, 1),
(53, '213120', 'IVA - Libre Disponibilidad ', 4, 1),
(54, '213230', 'Impuestos Varios a Pagar ', 4, 1),
(55, '213240', 'Imp. Gcia. Mín. Pres. a Pagar', 4, 1),
(56, '213250', 'Imp. Gcia. Mín. Pres. - Antic. ', 4, 1),
(57, '213260', 'Imp. a las Gcias. a Pagar', 4, 1),
(58, '213270', 'Imp. a las Gcias. - Anticipos', 4, 1),
(59, '213300', 'Municipalidad a Pagar', 4, 1),
(60, '214000', 'DEUDAS SOCIALES', 4, 0),
(61, '214100', 'Sueldos a Pagar', 4, 1),
(62, '214200', 'Régimen Seg. Social', 4, 1),
(63, '214300', 'Régimen Obra Social', 4, 1),
(64, '214400', 'Sindicato Choferes a Pagar ', 4, 1),
(65, '214500', 'Sindicato AOMA ', 4, 1),
(66, '214600', 'A. R. T. ', 4, 1),
(67, '215000', 'OTROS PASIVOS', 5, 0),
(68, '215100', 'IVA - Débito Fiscal', 5, 1),
(69, '215200', 'Retrib. a Gerentes a Pagar ', 5, 1),
(70, '300000', 'P A T R I M O N I ON E T O ', 7, 0),
(71, '310000', 'Capital', 7, 1),
(72, '320000', 'Ajuste Cuenta Capital', 7, 1),
(73, '330000', 'Reserva Legal', 7, 1),
(74, '340000', 'Resultados Acumulados', 7, 1),
(75, '350000', 'Resultados del Ejercicio ', 7, 1),
(76, '360000', 'Aportes Irrevoc. a cta.fut.sus ', 7, 1),
(77, '370000', 'R.E.A. ', 7, 1),
(78, '400000', 'E R O G A C I O N E S', 8, 0),
(79, '410000', 'COSTOS ', 8, 0),
(80, '410100', 'Costo del Yeso vendido ', 8, 1),
(81, '420000', 'COMPRAS', 8, 0),
(82, '420100', 'Compra Materia Prima ', 8, 1),
(83, '420200', 'Compra Bolsones', 8, 1),
(84, '420300', 'Compra Bolsas', 8, 1),
(85, '420400', 'Compras Varias ', 8, 1),
(86, '430000', 'GASTOS ', 8, 0),
(87, '431000', 'GASTOS DE ADMINISTRACION ', 8, 0),
(88, '431010', 'Gastos fact. "B" y "C" ', 8, 1),
(89, '431030', 'Honorarios ', 8, 1),
(90, '431050', 'Movilidad', 8, 1),
(91, '431060', 'Papelería y Utiles de Escritor ', 8, 1),
(92, '431080', 'Energía Eléctrica casa-oficina ', 8, 1),
(93, '431090', 'Teléfono y Fax ', 8, 1),
(94, '431100', 'Franqueos y Envíos Postales', 8, 1),
(95, '431110', 'Reparacion Máq. Oficina', 8, 1),
(96, '431120', 'Impuestos y Tasas', 8, 1),
(97, '431130', 'Amortizaciones Mue. y Utiles ', 8, 1),
(98, '431150', 'Intereses y Comisiones ', 8, 1),
(99, '431160', 'Jub. Autónomos Socios', 8, 1),
(100, '431170', 'Gastos Varios', 8, 1),
(101, '431190', 'Impuestos Internos ', 8, 1),
(102, '431200', 'Dpto. Gral. Irrigación ', 8, 1),
(103, '431210', 'Seguros vehículos adm. ', 8, 1),
(104, '431220', 'Gastos Representación', 8, 1),
(105, '431230', 'Honorarios Gerencia', 8, 1),
(106, '431240', 'OBRAS SANITARIAS - FCA ', 8, 1),
(107, '431250', 'Imp. Gcia. Mínima Presunta ', 8, 1),
(108, '431260', 'Imp. a las Ganancias ', 8, 1),
(109, '431270', 'Gtos Exportación ', 8, 1),
(110, '431271', 'Arreglos Edificio Fábrica', 8, 1),
(111, '431280', 'Gastos Construcción', 8, 1),
(112, '431299', 'Gastos Construcción', 8, 1),
(113, '431300', 'Iva no recuperable ', 8, 1),
(114, '432000', 'GASTOS DE COMERCIALIZACION ', 8, 0),
(115, '432030', 'Imp. a los Ingresos Brutos ', 8, 1),
(116, '432050', 'Movilidad', 8, 1),
(117, '432070', 'Fletes de Compras', 8, 1),
(118, '432100', 'Publicidad ', 8, 1),
(119, '433000', 'GASTOS DE PRODUCCION ', 8, 0),
(120, '433010', 'Sueldos y Jornales ', 8, 1),
(121, '433020', 'Cargas Sociales', 8, 1),
(122, '433030', 'Seguros Camiones ', 8, 1),
(123, '433040', 'Energía Eléctrica', 8, 1),
(124, '433050', 'Repuestos Máq. e Instalaciones ', 8, 1),
(125, '433060', 'Amortizaciones Bienes Uso', 8, 1),
(126, '433070', 'Fletes y Horas Máquinas', 8, 1),
(127, '433080', 'Combustible Fábrica', 8, 1),
(128, '433090', 'Gastos Camión nº 1 ', 8, 1),
(129, '433100', 'Viáticos Chofer', 8, 1),
(130, '433110', 'Retenciones Sueldos Obreros', 8, 1),
(131, '433120', 'Salario Familiar ', 8, 1),
(132, '433130', 'Seguro Vida y Sepelio', 8, 1),
(133, '433140', 'Servicio Coop. Trabajo ', 8, 1),
(134, '433150', 'Combustible Royon', 8, 1),
(135, '433160', 'Aceites y Lubricantes', 8, 1),
(136, '433170', 'Gastos Camión nº 2 ', 8, 1),
(137, '433180', 'Explotación Cantera', 8, 1),
(138, '433190', 'Seguro Vida Obligatorio', 8, 1),
(139, '434000', 'GASTOS DE FINANCIACION ', 8, 0),
(140, '434010', 'Intereses y Comis. Bancarias ', 8, 1),
(141, '434020', 'Actualiz. y Recargos ', 8, 1),
(142, '434080', 'Deudores Incobrables ', 8, 1),
(143, '434090', 'Descuentos Cedidos ', 8, 1),
(144, '434100', 'R.E.C.P.A.M. -Pérdida', 8, 1),
(145, '434200', 'Rdo por Tenencia - Negativo', 8, 1),
(146, '500000', 'I N G R E S O S', 9, 0),
(147, '510000', 'Ventas a Obras ', 9, 1),
(148, '520000', 'Ventas M-200 ', 9, 1),
(149, '530000', 'Descuentos Obtenidos ', 9, 1),
(150, '540000', 'Ventas de Fletes ', 9, 1),
(151, '550000', 'Ventas Exportaciones ', 9, 1),
(152, '560000', 'Rdo. Vta. Rodados - Utilidad ', 9, 1),
(153, '570000', 'Vtas Yeso para Agricultura ', 9, 1),
(154, '580000', 'Beneficio Cred. IVA Comb.', 9, 1),
(155, '580001', 'Benef. IVA - Dec. 814', 9, 1),
(156, '590000', 'Alquileres varios', 9, 1),
(157, '600000', 'R.E.C.P.A.M. ', 10, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallecobranza`
--

CREATE TABLE IF NOT EXISTS `detallecobranza` (
  `iddetallecobranza` int(11) NOT NULL AUTO_INCREMENT,
  `tipocobranza` int(11) NOT NULL COMMENT '0 - efectivo\n1 - transferencia bancaria\n2 - cheque',
  `importe` double NOT NULL,
  `transferenciabanco` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `chequefechacobro` date DEFAULT NULL,
  `chequefechaemision` date DEFAULT NULL,
  `nrocheque` bigint(20) DEFAULT NULL,
  `chequebanco` int(45) DEFAULT NULL,
  `cobranza_idcobranza` int(11) NOT NULL,
  `movimientobanco_idmovimientobanco` int(11) DEFAULT NULL,
  `cheque_idcheque` int(11) DEFAULT NULL,
  `movimientocaja_idmovimientocaja` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddetallecobranza`),
  KEY `fk_detallecobranza_cobranza1_idx` (`cobranza_idcobranza`),
  KEY `fk_detallecobranza_movimientobanco1_idx` (`movimientobanco_idmovimientobanco`),
  KEY `fk_detallecobranza_cheque1_idx` (`cheque_idcheque`),
  KEY `fk_detallecobranza_movimientocaja1_idx` (`movimientocaja_idmovimientocaja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallectactecliente`
--

CREATE TABLE IF NOT EXISTS `detallectactecliente` (
  `iddetallectactecliente` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `descripcion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo` int(11) NOT NULL COMMENT 'Tipo: si una factura, ND, DC, o cobranza (recibo)',
  `iddocumento` bigint(20) DEFAULT NULL,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `ctactecliente_idctactecliente` int(11) NOT NULL,
  `factura_idfactura` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddetallectactecliente`),
  KEY `fk_detallectactecliente_ctactecliente1_idx` (`ctactecliente_idctactecliente`),
  KEY `fk_detallectactecliente_factura1_idx` (`factura_idfactura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallectacteprov`
--

CREATE TABLE IF NOT EXISTS `detallectacteprov` (
  `iddetallectacteprov` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo` int(11) NOT NULL,
  `iddocumento` int(11) DEFAULT NULL,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `ctacteprov_idctacteprov` int(11) NOT NULL,
  PRIMARY KEY (`iddetallectacteprov`),
  KEY `fk_detallectacteprov_ctacteprov1_idx` (`ctacteprov_idctacteprov`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallefactura`
--

CREATE TABLE IF NOT EXISTS `detallefactura` (
  `iddetallefactura` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` double NOT NULL,
  `idproducto` int(11) NOT NULL,
  `nombreproducto` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `precioproducto` double DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `factura_idfactura` int(11) NOT NULL,
  PRIMARY KEY (`iddetallefactura`),
  KEY `fk_detallefactura_factura1_idx` (`factura_idfactura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalleordendepago`
--

CREATE TABLE IF NOT EXISTS `detalleordendepago` (
  `iddetalleordendepago` int(11) NOT NULL AUTO_INCREMENT,
  `tipoordendepago` int(11) DEFAULT NULL,
  `importe` double DEFAULT NULL,
  `transferenciabanco` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `chequetitular` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `chequecuittitular` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `chequefechacobro` date DEFAULT NULL,
  `chequefechaingreso` date DEFAULT NULL,
  `nrocheque` bigint(20) DEFAULT NULL,
  `chequebanco` int(11) DEFAULT NULL,
  `ordendepago_idordendepago` int(11) NOT NULL,
  `movimientocaja_idmovimientocaja` int(11) DEFAULT NULL,
  `cheque_idcheque` int(11) DEFAULT NULL,
  `movimientobanco_idmovimientobanco` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddetalleordendepago`),
  KEY `fk_detalleordendepago_ordendepago1_idx` (`ordendepago_idordendepago`),
  KEY `fk_detalleordendepago_movimientocaja1_idx` (`movimientocaja_idmovimientocaja`),
  KEY `fk_detalleordendepago_cheque1_idx` (`cheque_idcheque`),
  KEY `fk_detalleordendepago_movimientobanco1_idx` (`movimientobanco_idmovimientobanco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE IF NOT EXISTS `empleado` (
  `idempleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuil` varchar(13) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fechaingreso` date DEFAULT NULL,
  `legajo` bigint(20) DEFAULT NULL,
  `area_idarea` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`idempleado`),
  KEY `fk_empleado_area1_idx` (`area_idarea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

CREATE TABLE IF NOT EXISTS `empresa` (
  `idempresa` int(11) NOT NULL,
  `razonsocial` varchar(200) CHARACTER SET utf8 NOT NULL,
  `nombrefantasia` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cuit` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `direccion` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `telefono` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `telefax` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `tiposociedad` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `localidad_idlocalidad` int(11) NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`idempresa`),
  KEY `fk_empresa_localidad1_idx` (`localidad_idlocalidad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE IF NOT EXISTS `factura` (
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `nrodefactura` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tipofactura` int(11) NOT NULL COMMENT 'Indica que tipo de factura es. 0 tipo A, 1 tipo B, 2 tipo C',
  `nroremito` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `cliente_idcliente` int(11) NOT NULL,
  `formadepago` int(11) NOT NULL,
  `importe` double NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'la columna anulada es para definir el estado de la factura: (1) anulada, igual se puede apreciar en el listado de facturas; (0) no anulada, factura normal.\nEn el caso de borrar una factura, se elimina por completo el registro y por lo tanto el "nrodefactura"',
  `descrecar` double DEFAULT NULL,
  `tipodescrecar` int(11) DEFAULT NULL,
  `iva` double DEFAULT NULL,
  `presupuesto` tinyint(1) NOT NULL,
  `nropresupuesto` int(11) NOT NULL,
  `subtotal` double NOT NULL,
  `subcuenta_idsubcuenta` int(11) DEFAULT NULL,
  `cuenta_idcuenta` int(11) DEFAULT NULL,
  PRIMARY KEY (`idfactura`),
  KEY `fk_factura_cliente1_idx` (`cliente_idcliente`),
  KEY `fk_factura_formadepago1_idx` (`formadepago`),
  KEY `fk_factura_subcuenta1_idx` (`subcuenta_idsubcuenta`),
  KEY `fk_factura_cuenta1_idx` (`cuenta_idcuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ivamovimiento`
--

CREATE TABLE IF NOT EXISTS `ivamovimiento` (
  `idivamovimiento` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `tipoiva` int(11) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `proveedor_idproveedor` int(11) DEFAULT NULL,
  `cliente_idcliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`idivamovimiento`),
  KEY `fk_ivamovimiento_proveedor1_idx` (`proveedor_idproveedor`),
  KEY `fk_ivamovimiento_cliente1_idx` (`cliente_idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localidad`
--

CREATE TABLE IF NOT EXISTS `localidad` (
  `idlocalidad` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `codigopostal` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `provincia_idprovincia` int(11) NOT NULL,
  PRIMARY KEY (`idlocalidad`),
  KEY `fk_localidad_provincia1_idx` (`provincia_idprovincia`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=635 ;

--
-- Volcado de datos para la tabla `localidad`
--

INSERT INTO `localidad` (`idlocalidad`, `nombre`, `codigopostal`, `provincia_idprovincia`) VALUES
(1, 'AZUL', NULL, 1),
(2, 'PUAN', NULL, 1),
(3, 'LA MATANZA', NULL, 1),
(4, 'TIGRE', NULL, 1),
(5, '25 DE MAYO', NULL, 1),
(6, 'TRENQUE LAUQUEN', NULL, 1),
(7, '9 DE JULIO', NULL, 1),
(8, 'LANUS', NULL, 1),
(9, 'LA PLATA', NULL, 1),
(10, 'MONTE', NULL, 1),
(11, 'PEHUAJO', NULL, 1),
(12, 'SAN ISIDRO', NULL, 1),
(13, 'PERGAMINO', NULL, 1),
(14, 'ALBERTI', NULL, 1),
(15, 'CHASCOMUS', NULL, 1),
(16, 'ESTEBAN ECHEVERRIA', NULL, 1),
(17, 'MERCEDES', NULL, 1),
(18, 'BAHIA BLANCA', NULL, 1),
(19, 'MERLO', NULL, 1),
(20, 'JUNIN', NULL, 1),
(21, 'GUAMINI', NULL, 1),
(22, 'LUJAN', NULL, 1),
(23, 'LEANDRO N.ALEM', NULL, 1),
(24, 'MATANZA', NULL, 1),
(25, 'GENERAL PAZ', NULL, 1),
(26, 'SAN VICENTE', NULL, 1),
(27, 'CA', NULL, 1),
(28, 'ALMIRANTE BROWN', NULL, 1),
(29, 'CNL.DE MARINA  L.ROSALES', NULL, 1),
(30, 'BARADERO', NULL, 1),
(31, 'SAAVEDRA', NULL, 1),
(32, 'BRANDSEN', NULL, 1),
(33, 'GENERAL SARMIENTO', NULL, 1),
(34, 'TAPALQUE', NULL, 1),
(35, 'SALADILLO', NULL, 1),
(36, 'MAGDALENA', NULL, 1),
(37, 'GONZALES CHAVES', NULL, 1),
(38, 'GENERAL PINTO', NULL, 1),
(39, 'NAVARRO', NULL, 1),
(40, 'DAIREAUX', NULL, 1),
(41, 'LOBOS', NULL, 1),
(42, 'CORONEL DORREGO', NULL, 1),
(43, 'ADOLFO ALSINA', NULL, 1),
(44, 'COLON', NULL, 1),
(45, 'GENERAL ARENALES', NULL, 1),
(46, 'LINCOLN', NULL, 1),
(47, 'VILLARINO', NULL, 1),
(48, 'VICENTE LOPEZ', NULL, 1),
(49, 'BARTOLOME MITRE', NULL, 1),
(50, 'EXALTACION DE LA CRUZ', NULL, 1),
(51, 'SALTO', NULL, 1),
(52, 'BRAGADO', NULL, 1),
(53, 'ZARATE', NULL, 1),
(54, 'AVELLANEDA', NULL, 1),
(55, 'AYACUCHO', NULL, 1),
(56, 'SAN ANDRES DE GILES', NULL, 1),
(57, 'TANDIL', NULL, 1),
(58, 'RIVADAVIA', NULL, 1),
(59, 'PATAGONES', NULL, 1),
(60, 'GRL.VIAMONTE', NULL, 1),
(61, 'CNL.DE MARINA LEONARDO ROSALES', NULL, 1),
(62, 'BALCARCE', NULL, 1),
(63, 'TRES ARROYOS', NULL, 1),
(64, 'GENERAL VILLEGAS', NULL, 1),
(65, 'LOMAS DE ZAMORA', NULL, 1),
(66, 'BERISSO', NULL, 1),
(67, 'JUAREZ', NULL, 1),
(68, 'GRL.PUEYRREDON', NULL, 1),
(69, 'CORONEL SUAREZ', NULL, 1),
(70, 'ESCOBAR', NULL, 1),
(71, 'CARLOS CASARES', NULL, 1),
(72, 'CHIVILCOY', NULL, 1),
(73, 'BERAZATEGUI', NULL, 1),
(74, 'QUILMES', NULL, 1),
(75, 'TORQUINST', NULL, 1),
(76, '3 DE FEBRERO', NULL, 1),
(77, 'OLAVARRIA', NULL, 1),
(78, 'PELLEGRINI', NULL, 1),
(79, 'GENERAL BELGANO', NULL, 1),
(80, 'FLORENCIO VARELA', NULL, 1),
(81, 'SALLIQUELO', NULL, 1),
(82, 'CNL.DE MARINA L.ROSALES', NULL, 1),
(83, 'MAR CHIQUITA', NULL, 1),
(84, 'GENERAL PUEYRREDON', NULL, 1),
(85, 'CAMPANA', NULL, 1),
(86, 'GRL.SARMIENTO', NULL, 1),
(87, 'ROJAS', NULL, 1),
(88, 'SARMIENTO', NULL, 1),
(89, 'CARMEN DE ARECO', NULL, 1),
(90, 'PILA', NULL, 1),
(91, 'TRES DE FEBRERO', NULL, 1),
(92, 'MORON', NULL, 1),
(93, 'CASTELLI', NULL, 1),
(94, 'CHACABUCO', NULL, 1),
(95, 'GENERAL VIAMONTE', NULL, 1),
(96, 'RAUCH', NULL, 1),
(97, 'GENERAL BELGRANO', NULL, 1),
(98, 'TORNQUIST', NULL, 1),
(99, 'NECOCHEA', NULL, 1),
(100, 'MARCOS PAZ', NULL, 1),
(101, 'CARLOS TEJEDOR', NULL, 1),
(102, 'SAN PEDRO', NULL, 1),
(103, 'GENERAL ALVARADO', NULL, 1),
(104, 'SAN NICOLAS', NULL, 1),
(105, 'HIPOLITO YRIGOYEN', NULL, 1),
(106, 'LAS FLORES', NULL, 1),
(107, 'CORONEL PRINGLES', NULL, 1),
(108, 'GENERAL SAN MARTIN', NULL, 1),
(109, 'BENITO JUAREZ', NULL, 1),
(110, 'SAN CAYETANO', NULL, 1),
(111, 'ADOLFO GONZALES CHAVES', NULL, 1),
(112, 'DOLORES', NULL, 1),
(113, 'SAN ANTONIO', NULL, 1),
(114, 'LOBERIA', NULL, 1),
(115, 'RAMALLO', NULL, 1),
(116, 'GENERAL ALVEAR', NULL, 1),
(117, 'ENSENADA', NULL, 1),
(118, 'TORDILLO', NULL, 1),
(119, 'GENERAL GUIDO', NULL, 1),
(120, 'GENERAL LAS HERAS', NULL, 1),
(121, 'GENERAL JUAN MADARIAGA', NULL, 1),
(122, 'GENERAL LA MADRID', NULL, 1),
(123, 'GENERAL LAVALLE', NULL, 1),
(124, 'GENERAL RODRIGUEZ', NULL, 1),
(125, 'GENERAL VLLEGAS', NULL, 1),
(126, 'ADOLFO GONZALEZ CHAVES', NULL, 1),
(127, 'CORONEL DE MARINA L.ROSALES', NULL, 1),
(128, 'BOLIVAR', NULL, 1),
(129, 'SAN FERNANDO', NULL, 1),
(130, 'CAPITAN SARMIENTO', NULL, 1),
(131, 'ROQUE PEREZ', NULL, 1),
(132, 'MORENO', NULL, 1),
(133, 'LAPRIDA', NULL, 1),
(134, 'MAIPU', NULL, 1),
(135, 'ECHEVERRIA', NULL, 1),
(136, 'PILAR', NULL, 1),
(137, 'CORONEL DE MARINA L. ROSALES', NULL, 1),
(138, 'SUIPACHA', NULL, 1),
(139, 'SAN ANTONIO DE ARECO', NULL, 1),
(140, 'BARAZATEGUI', NULL, 1),
(141, 'ALSINA', NULL, 1),
(142, 'LEANDRO N. ELEM', NULL, 1),
(143, 'GRL.SAN MARTIN', NULL, 1),
(144, 'CORONEL', NULL, 1),
(145, 'CAPAYAN', NULL, 2),
(146, 'ANDALGALA', NULL, 2),
(147, 'EL ALTO', NULL, 2),
(148, 'SANTA ROSA', NULL, 2),
(149, 'ANCASTI', NULL, 2),
(150, 'PACLIN', NULL, 2),
(151, 'SANTA MARIA', NULL, 2),
(152, 'TINOGASTA', NULL, 2),
(153, 'LA PAZ', NULL, 2),
(154, 'VALLE VIEJO', NULL, 2),
(155, 'ANTOFAGASTA DE LA SIERRA', NULL, 2),
(156, 'BELEN', NULL, 2),
(157, 'SAN FERNANDO DEL VALLE DE CATAMARCA', NULL, 2),
(158, 'FRAY MAMERTO ESQUIU', NULL, 2),
(159, 'POMAN', NULL, 2),
(160, 'AMBATO', NULL, 2),
(161, 'INDEPENDENCIA', NULL, 3),
(162, 'SAN FERNANDO', NULL, 3),
(163, 'PRIMERO DE MAYO', NULL, 3),
(164, 'FRAY JUSTO SANTA MARIA DE ORO', NULL, 3),
(165, 'SARGENTO CABRAL', NULL, 3),
(166, 'GENERAL GUEMES', NULL, 3),
(167, 'TAPENAGA', NULL, 3),
(168, 'CHACABUCO', NULL, 3),
(169, 'LIBERTADOR GRL.SAN MARTIN', NULL, 3),
(170, '25 DE MAYO', NULL, 3),
(171, '12 DE OCTUBRE', NULL, 3),
(172, 'COMANDANTE FERNANDEZ', NULL, 3),
(173, 'QUITILIPI', NULL, 3),
(174, 'MAYOR LUIS J.FONTANA', NULL, 3),
(175, 'LIBERTAD', NULL, 3),
(176, 'BERMEJO', NULL, 3),
(177, 'ALMIRANTE BROWN', NULL, 3),
(178, 'MEYOR LUIS J.FONTANA', NULL, 3),
(179, 'GENERAL BELGRANO', NULL, 3),
(180, 'LIBERTADOR GRL. SAN MARTIN', NULL, 3),
(181, 'GENERAL DONOVAN', NULL, 3),
(182, 'SAN LORENZO', NULL, 3),
(183, 'LEBERTADOR GRL.SAN MARTIN', NULL, 3),
(184, 'MAIPU', NULL, 3),
(185, 'O''HIGGINS', NULL, 3),
(186, '9 DE JULIO', NULL, 3),
(187, 'LIBERTADOR SAN MARTIN', NULL, 3),
(188, 'RIO SENGUERR', NULL, 4),
(189, 'MARTIRES', NULL, 4),
(190, 'ESCALANTE', NULL, 4),
(191, 'GAIMAN', NULL, 4),
(192, 'SARMIENTO', NULL, 4),
(193, 'CUSHAMEN', NULL, 4),
(194, 'FLORENTINO AMEGHINO', NULL, 4),
(195, 'PASO DE INDIOS', NULL, 4),
(196, 'TELSEN', NULL, 4),
(197, 'LANGUI', NULL, 4),
(198, 'GASTRE', NULL, 4),
(199, 'FUTALEUFU', NULL, 4),
(200, 'TEHUELCHES', NULL, 4),
(201, 'RAWSON', NULL, 4),
(202, 'BIEDMA', NULL, 4),
(203, 'RIO CUARTO', NULL, 5),
(204, 'TOTORAL', NULL, 5),
(205, 'COLON', NULL, 5),
(206, 'MINAS', NULL, 5),
(207, 'PUNILLA', NULL, 5),
(208, 'JUAREZ CELMAN', NULL, 5),
(209, 'MARCOS JUAREZ', NULL, 5),
(210, 'SAN JUSTO', NULL, 5),
(211, 'TERCERO ARRIBA', NULL, 5),
(212, 'RIO SECO', NULL, 5),
(213, 'CORDOBA', NULL, 5),
(214, 'SANTA MARIA', NULL, 5),
(215, 'SAN ALBERTO', NULL, 5),
(216, 'UNION', NULL, 5),
(217, 'POCHO', NULL, 5),
(218, 'CALAMUCHITA', NULL, 5),
(219, 'ISCHILIN', NULL, 5),
(220, 'GENERAL SAN MARTIN', NULL, 5),
(221, 'RIO PRIMERO', NULL, 5),
(222, 'CRUZ DEL EJE', NULL, 5),
(223, 'GRL.ROCA', NULL, 5),
(224, 'GENERAL ROCA', NULL, 5),
(225, 'SOBREMONTE', NULL, 5),
(226, 'RIO SEGUNDO', NULL, 5),
(227, 'TULUMBA', NULL, 5),
(228, 'SAN JAVIER', NULL, 5),
(229, 'PRESIDENTE ROQUE SAEZ PE', NULL, 5),
(230, 'PRESIDENTE ROQUE SAENZ PE', NULL, 5),
(232, 'CRUZ DE EJE', NULL, 5),
(233, 'CORONEL PRINGLES', NULL, 5),
(234, 'RIO TERCERO', NULL, 5),
(235, 'CVALAMUCHITA', NULL, 5),
(236, 'SAN ROQUE', NULL, 6),
(237, 'MONTE CASEROS', NULL, 6),
(238, 'GENERAL ALVEAR', NULL, 6),
(239, 'CURUZU CUATIA', NULL, 6),
(240, 'SAN MARTIN', NULL, 6),
(241, 'MERCEDES', NULL, 6),
(242, 'SALADAS', NULL, 6),
(243, 'ITUZAINGO', NULL, 6),
(244, 'BERON DE ASTRADA', NULL, 6),
(245, 'BELLA VISTA', NULL, 6),
(246, 'SAN LUIS DEL PALMAR', NULL, 6),
(247, 'CORRIENTES', NULL, 6),
(248, 'LAVALLE', NULL, 6),
(249, 'PASO DE LOS LIBRES', NULL, 6),
(250, 'GOYA', NULL, 6),
(251, 'EMPEDRADO', NULL, 6),
(252, 'SAUCE', NULL, 6),
(253, 'GENERAL PAZ', NULL, 6),
(254, 'SANTO TOME', NULL, 6),
(255, 'SAN MIGUEL', NULL, 6),
(256, 'CONCEPCION', NULL, 6),
(257, 'ESQUINA', NULL, 6),
(258, 'SAN COSME', NULL, 6),
(259, 'ITATI', NULL, 6),
(260, 'MBURUCUYA', NULL, 6),
(261, 'URUGUAY', NULL, 7),
(262, 'NOGOYA', NULL, 7),
(263, 'TALA', NULL, 7),
(264, 'GUALEGUAY', NULL, 7),
(265, 'DIAMANTE', NULL, 7),
(266, 'PARANA', NULL, 7),
(267, 'GUALEGUAYCHU', NULL, 7),
(268, 'COLON', NULL, 7),
(269, 'VICTORIA', NULL, 7),
(270, 'VILLAGUAY', NULL, 7),
(271, 'FELICIANO', NULL, 7),
(272, 'CONCORDIA', NULL, 7),
(273, 'LA PAZ', NULL, 7),
(274, 'FEDERACION', NULL, 7),
(275, 'FEDERAL', NULL, 7),
(276, 'CASTELLANOS', NULL, 7),
(277, 'PILAGAS', NULL, 8),
(278, 'PATI', NULL, 8),
(279, 'PILCOMAYO', NULL, 8),
(280, 'BERMEJO', NULL, 8),
(281, 'PIRANE', NULL, 8),
(282, 'FORMOSA', NULL, 8),
(283, 'MATACOS', NULL, 8),
(284, 'RAMON LISTA', NULL, 8),
(285, 'PILLAGAS', NULL, 8),
(286, 'LAISHI', NULL, 8),
(287, 'LEDESMA', NULL, 9),
(288, 'COCHINOCA', NULL, 9),
(289, 'EL CARMEN', NULL, 9),
(290, 'TUMBAYA', NULL, 9),
(291, 'JUJUY', NULL, 9),
(292, 'YAVI', NULL, 9),
(293, 'HUMAHUACA', NULL, 9),
(294, 'RINCONADA', NULL, 9),
(295, 'VALLE GRANDE', NULL, 9),
(296, 'SUSQUES', NULL, 9),
(297, 'SANTA CATALINA', NULL, 9),
(298, 'SAN ANTONIO', NULL, 9),
(299, 'SANTA BARBARA', NULL, 9),
(300, 'SAN PEDRO', NULL, 9),
(301, 'TILCARA', NULL, 9),
(302, 'LADESMA', NULL, 9),
(303, 'HUCAL', NULL, 10),
(304, 'REALICO', NULL, 10),
(305, 'MARA CO', NULL, 10),
(306, 'QUEMUQUEMU', NULL, 10),
(307, 'CHICAL CO', NULL, 10),
(308, 'GUATRACHE', NULL, 10),
(309, 'LA PAMPA', NULL, 10),
(310, 'CALEUCALEU', NULL, 10),
(311, 'TRENEL', NULL, 10),
(312, 'UTRACAN', NULL, 10),
(313, 'ATREUCO', NULL, 10),
(314, 'TOAY', NULL, 10),
(315, 'CHAPADLEUFU', NULL, 10),
(316, 'CONELO', NULL, 10),
(317, 'PUELEN', NULL, 10),
(318, 'RANCUL', NULL, 10),
(319, 'QUEMU QUEMU', NULL, 10),
(320, 'LOVENTUE', NULL, 10),
(321, 'CONHELO', NULL, 10),
(322, 'CATRILO', NULL, 10),
(323, 'CHAPALEUFU', NULL, 10),
(324, 'ULTRACAN', NULL, 10),
(325, 'CHALILEO', NULL, 10),
(326, 'LIHUEL CALEL', NULL, 10),
(327, 'MARACO', NULL, 10),
(328, 'CALEU CALEU', NULL, 10),
(329, 'CURACO', NULL, 10),
(330, 'LIMAY MAHUIDA', NULL, 10),
(331, 'CASTRO BARROS', NULL, 11),
(332, 'GENERAL SAN MARTIN', NULL, 11),
(333, 'GENERAL LAVALLE', NULL, 11),
(334, 'ARAUCO', NULL, 11),
(335, 'GRAL.ANGEL V.PE', NULL, 11),
(336, 'SAN BLAS DE LOS SAUCES', NULL, 11),
(337, 'INDEPENDENCIA', NULL, 11),
(338, 'GENERAL OCAMPO', NULL, 11),
(339, 'CHILECITO', NULL, 11),
(340, 'FAMATINA', NULL, 11),
(341, 'GRL.JUAN FACUNDO QUIROGA', NULL, 11),
(342, 'GRL.ANGEL V. PE', NULL, 11),
(343, 'GENERAL BELGRANO', NULL, 11),
(344, 'GENERAL SARMIENTO', NULL, 11),
(345, 'LA RIOJA', NULL, 11),
(346, 'GDOR. GORDILLO', NULL, 11),
(347, 'GENERAL ANGEL VICENTE PE', NULL, 11),
(348, 'GOBERNADOR GORDILLO', NULL, 11),
(349, 'ROSARIO VERA PE', NULL, 11),
(350, 'GRL.SAN MARTIN', NULL, 11),
(351, 'GENERAL LA MADRID', NULL, 11),
(352, 'GENERAL JUAN FACUNDO QUIROGA', NULL, 11),
(353, 'GENERALOCAMPO', NULL, 11),
(354, 'SANAGASTA', NULL, 11),
(355, 'SAN RAFAEL', '5600', 12),
(356, 'LUJAN', NULL, 12),
(357, 'MALARGUE', NULL, 12),
(358, 'GUAYMALLEN', NULL, 12),
(359, 'LAVALLE', NULL, 12),
(360, 'JUNIN', NULL, 12),
(361, 'TUPUNGATO', NULL, 12),
(362, 'RIVADAVIA', NULL, 12),
(363, 'MAIPU', NULL, 12),
(364, 'GODOY CRUZ', NULL, 12),
(365, 'GENERAL ALVEAR', NULL, 12),
(366, 'LA PAZ', NULL, 12),
(367, 'TUNUYAN', NULL, 12),
(368, 'SAN CARLOS', NULL, 12),
(369, 'LAS HERAS', NULL, 12),
(370, 'LUJAN DE CUYO', NULL, 12),
(371, 'SAN MARTIN', NULL, 12),
(372, 'SANTA ROSA', NULL, 12),
(373, 'MENDOZA', NULL, 12),
(374, '25 DE MAYO', NULL, 13),
(375, 'IGUAZU', NULL, 13),
(376, 'EL DORADO', NULL, 13),
(377, 'LEANDRO N. ALEM', NULL, 13),
(378, 'APOSTOLES', NULL, 13),
(379, 'CAINGUAS', NULL, 13),
(380, 'LEANDRO N.ALEM', NULL, 13),
(381, 'CONCEPCION', NULL, 13),
(382, 'SAN PEDRO', NULL, 13),
(383, 'CANDELARIA', NULL, 13),
(384, 'GRL.MANUEL BELGRANO', NULL, 13),
(385, 'OBERA', NULL, 13),
(386, 'LIBERTADOR GRL.SAN MARTIN', NULL, 13),
(387, 'SAN IGNACIO', NULL, 13),
(388, 'MONTECARLO', NULL, 13),
(389, 'GENERAL MANUEL BELGRANO', NULL, 13),
(390, 'LEBERTADOR GRL.SAN MARTIN', NULL, 13),
(391, 'EL GUARANI', NULL, 13),
(392, 'ELDORADO', NULL, 13),
(393, 'POSADAS', NULL, 13),
(394, 'GUARANI', NULL, 13),
(395, 'SAN JAVIER', NULL, 13),
(396, 'LIBERTADOR GRL. SAN MARTIN', NULL, 13),
(397, 'COLLON CURA', NULL, 14),
(398, 'ALUMINE', NULL, 14),
(399, 'MINAS', NULL, 14),
(400, 'A', NULL, 14),
(401, 'CONFLUENCIA', NULL, 14),
(402, 'CHOS MALAL', NULL, 14),
(403, 'PICUNCHES', NULL, 14),
(404, 'NORQUIN', NULL, 14),
(405, 'PEHUENCHES', NULL, 14),
(406, 'LONCOPUE', NULL, 14),
(407, 'HUILICHES', NULL, 14),
(408, 'ZAPALA', NULL, 14),
(409, 'CATAN LIL', NULL, 14),
(410, '', NULL, 14),
(411, 'LOS LAGOS', NULL, 14),
(412, 'PICUN LEUFU', NULL, 14),
(413, 'LACAR', NULL, 14),
(414, '', NULL, 14),
(415, 'VALCHETA', NULL, 15),
(416, '25 DE MAYO', NULL, 15),
(417, 'EL CUY', NULL, 15),
(418, '', NULL, 15),
(419, 'GENERAL ROCA', NULL, 15),
(420, 'AVELLANEDA', NULL, 15),
(421, 'CONESA', NULL, 15),
(422, 'PICHI MAHUIDA', NULL, 15),
(423, 'SAN ANTONIO', NULL, 15),
(424, 'PILCANIYEU', NULL, 15),
(425, '9 DE JULIO', NULL, 15),
(426, 'ADOLFO ALSINA', NULL, 15),
(427, 'BARILOCHE', NULL, 15),
(428, 'PIHI MAHUIDA', NULL, 15),
(429, 'LA VI', NULL, 16),
(430, 'SAN MARTIN', NULL, 16),
(431, 'ORAN', NULL, 16),
(432, 'ANTA', NULL, 16),
(433, 'GRAL.JOSE DE SAN MARTIN', NULL, 16),
(434, 'GUACHIPAS', NULL, 16),
(435, 'ROSARIO DE LA FRONTERA', NULL, 16),
(436, 'RIVADAVIA', NULL, 16),
(437, 'METAN', NULL, 16),
(438, 'SAN CARLOS', NULL, 16),
(439, 'GRL.GUEMES', NULL, 16),
(440, 'CACHI', NULL, 16),
(441, 'ROSARIO DE LERMA', NULL, 16),
(442, 'CAFAYATE', NULL, 16),
(443, 'LOS ANDES', NULL, 16),
(444, 'GRL.JOSE DE SAN MARTIN', NULL, 16),
(445, 'SALTA', NULL, 16),
(446, 'GRL.SAN MARTIN', NULL, 16),
(447, 'GENERAL GUEMES', NULL, 16),
(448, 'CERRILLOS', NULL, 16),
(449, 'CHICOANA', NULL, 16),
(450, 'LA POMA', NULL, 16),
(451, 'LA CAPITAL', NULL, 16),
(452, 'CANDELARIA', NULL, 16),
(453, 'ROSARIO', NULL, 16),
(454, 'IRUYA', NULL, 16),
(455, 'LA CALDERA', NULL, 16),
(456, 'LOA ANDES', NULL, 16),
(457, 'MOLINOS', NULL, 16),
(458, 'SANTA VICTORIA', NULL, 16),
(459, '9 DE JULIO', NULL, 17),
(460, 'JACHAL', NULL, 17),
(461, 'ALBARDON', NULL, 17),
(462, '25 DE MAYO', NULL, 17),
(463, 'SANTA LUCIA', NULL, 17),
(464, 'ANGACO', NULL, 17),
(465, 'IGLESIA', NULL, 17),
(466, 'VALLE FERTIL', NULL, 17),
(467, 'CALINGASTA', NULL, 17),
(468, 'RIVADAVIA', NULL, 17),
(469, 'CAUCETE', NULL, 17),
(470, 'SARMIENTO', NULL, 17),
(471, 'POCITO', NULL, 17),
(472, 'SAN MARTIN', NULL, 17),
(473, 'CHIMBAS', NULL, 17),
(474, 'IGLESIAS', NULL, 17),
(475, 'ULLUN', NULL, 17),
(476, 'RAWSON', NULL, 17),
(477, 'SAN JUAN', NULL, 17),
(478, 'ZONDA', NULL, 17),
(479, 'BELGRANO', NULL, 18),
(480, 'CHACABUCO', NULL, 18),
(481, 'LA CAPITAL', NULL, 18),
(482, 'GOBERNADOR DUPUY', NULL, 18),
(483, 'GRL.PEDERNERA', NULL, 18),
(484, 'AYACUCHO', NULL, 18),
(485, 'JUNIN', NULL, 18),
(486, 'GONERNADOR DUPUY', NULL, 18),
(487, 'CORONEL PRINGLES', NULL, 18),
(488, 'GENERAL PEDERNERA', NULL, 18),
(489, 'GOBERNADOR DUVAL', NULL, 18),
(490, 'IGLESIA', NULL, 18),
(491, 'LIBERTADOR GRL. SAN MARTIN', NULL, 18),
(492, 'LIBERTADOR GRL.SAN MARTIN', NULL, 18),
(493, 'LIBERTADOR GR.SAN MARTIN', NULL, 18),
(494, 'CAUCETE', NULL, 18),
(495, 'GUER AIKE', NULL, 19),
(496, 'DESEADO', NULL, 19),
(497, 'RIO CHICO', NULL, 19),
(498, 'MAGALLANES', NULL, 19),
(499, 'LAGO ARGENTINO', NULL, 19),
(500, 'CORPEN AIKE', NULL, 19),
(501, 'LAGO BUENOS AIRES', NULL, 19),
(502, 'GENERAL LOPEZ', NULL, 20),
(503, 'ROSARIO', NULL, 20),
(504, 'GENERAL OBLIGADO', NULL, 20),
(505, 'CONSTITUCION', NULL, 20),
(506, 'SAN LORENZO', NULL, 20),
(507, 'SAN JAVIER', NULL, 20),
(508, 'LA CAPITAL', NULL, 20),
(509, 'SAN CRISTOBAL', NULL, 20),
(510, 'IRIONDO', NULL, 20),
(511, 'CASTELLANOS', NULL, 20),
(512, 'NUEVE DE JULIO', NULL, 20),
(513, 'CASEROS', NULL, 20),
(514, 'SAN JERONIMO', NULL, 20),
(515, 'BELGRANO', NULL, 20),
(516, 'SANTA FE', NULL, 20),
(517, 'SAN JUSTO', NULL, 20),
(518, 'GRL.OBLIGADO', NULL, 20),
(519, 'LA CAPUTAL', NULL, 20),
(520, 'GRL.LOPEZ', NULL, 20),
(521, 'VERA', NULL, 20),
(522, '9 DE JULIO', NULL, 20),
(523, 'SAN MARTIN', NULL, 20),
(524, 'LAS COLONIAS', NULL, 20),
(525, 'GARAY', NULL, 20),
(526, 'CASTELANOS', NULL, 20),
(527, 'LAS COLINAS', NULL, 20),
(528, 'BANDA', NULL, 21),
(529, 'MORENO', NULL, 21),
(530, 'ALBERDI', NULL, 21),
(531, 'PELLEGRINI', NULL, 21),
(532, 'OJO DE AGUA', NULL, 21),
(533, 'RIO HONDO', NULL, 21),
(534, 'GENERAL TABOADA', NULL, 21),
(535, 'CHOYA', NULL, 21),
(536, 'SANTIAGO DEL ESTERO', NULL, 21),
(537, 'AGUIRRE', NULL, 21),
(538, 'SILIPICA', NULL, 21),
(539, 'BELGRANO', NULL, 21),
(540, 'FIGUEROA', NULL, 21),
(541, 'SALAVINA', NULL, 21),
(542, 'QUEBRACHOS', NULL, 21),
(543, 'ROBLES', NULL, 21),
(544, 'AVELLANEDA', NULL, 21),
(545, 'JIMENEZ', NULL, 21),
(546, 'ATAMISQUI', NULL, 21),
(547, 'SAN MARTIN', NULL, 21),
(548, 'MATARA', NULL, 21),
(549, 'SALAYINA', NULL, 21),
(550, 'GUASAYAN', NULL, 21),
(551, 'COPO', NULL, 21),
(552, 'BRIGADIER JUAN FELIPE IBARRA', NULL, 21),
(553, 'DOBLES', NULL, 21),
(554, 'SARMIENTO', NULL, 21),
(555, 'LORETO', NULL, 21),
(556, 'MITRE', NULL, 21),
(557, 'RIVADAVIA', NULL, 21),
(558, 'USHUAIA', NULL, 22),
(559, 'ISLAS DEL ATLANTICO SUR', NULL, 22),
(560, 'SECTOR ANTARTICO ARGENTINO', NULL, 22),
(561, 'RIO GRANDE', NULL, 22),
(562, 'IS.DEL ATLANTICO SUR E IS.MALVINAS', NULL, 22),
(563, 'ANTARTIDA ARGENTINA', NULL, 22),
(564, 'BURRUYACU', NULL, 23),
(565, 'TRANCAS', NULL, 23),
(566, 'MONTEROS', NULL, 23),
(567, 'LEALES', NULL, 23),
(568, 'CRUZ ALTA', NULL, 23),
(569, 'RIO CHICO', NULL, 23),
(570, 'CHICLIGASTA', NULL, 23),
(571, 'TAFI', NULL, 23),
(572, 'GRANEROS', NULL, 23),
(573, 'FAMAILLA', NULL, 23),
(574, 'SAN MIGUEL DE TUCUM', NULL, 23),
(575, 'CAPITAL FEDERAL', NULL, 1),
(576, 'VILLA GESELL', NULL, 1),
(577, 'SAN LUIS', NULL, 18),
(578, 'COMODORO RIVADAVIA', NULL, 4),
(579, 'LOS MOLLES', NULL, 12),
(580, 'LAS LE', NULL, 12),
(581, 'MERLO', NULL, 18),
(582, 'SAN BERNARDO', NULL, 1),
(583, 'ESQUEL', NULL, 4),
(584, 'MAR DEL PLATA', NULL, 1),
(585, 'VILLA LA ANGOSTURA', NULL, 14),
(586, 'NEUQUEN', NULL, 14),
(587, 'GENERAL FERNANDEZ ORO', NULL, 15),
(588, 'LAS GRUTAS', NULL, 15),
(589, 'POTRERO DE LOS FUNES', NULL, 18),
(590, 'PERITO MORENO', NULL, 19),
(591, 'EL CALAFATE', NULL, 19),
(592, 'VILLA CARLOS PAZ', NULL, 5),
(593, 'VILLA GENERAL BELGRANO', NULL, 5),
(594, 'VILLA ATUEL (SAN RAFAEL)', NULL, 12),
(595, 'PUERTO MADRYN', NULL, 4),
(596, 'CORTADERAS', NULL, 18),
(597, 'VALLE GRANDE (SAN RAFAEL)', NULL, 12),
(598, 'RESISTENCIA', NULL, 3),
(599, 'SAN MARTIN DE LOS ANDES', NULL, 14),
(600, 'PINAMAR', NULL, 1),
(601, 'CARILO', NULL, 1),
(602, 'EL CHALTEN', NULL, 19),
(603, 'RIO GALLEGOS', NULL, 19),
(604, 'PUERTO DESEADO', NULL, 19),
(605, 'JUNIN DE LOS ANDES', NULL, 14),
(606, 'CIPOLLETTI', NULL, 15),
(607, 'EL BOLSON', NULL, 15),
(608, 'RAMA CAIDA (SAN RAFAEL)', NULL, 12),
(609, 'VILLA MERCEDES', NULL, 18),
(610, 'LA PUNTILLA', NULL, 12),
(611, 'CHACRAS DE CORIA', NULL, 12),
(612, 'MIRAMAR', NULL, 1),
(613, 'LOS CARDALES', NULL, 1),
(614, 'CLAROMECO', NULL, 1),
(615, 'MAR DE LAS PAMPAS', NULL, 1),
(616, 'SANTA ROSA DE CALAMUCHITA', NULL, 5),
(617, 'VALERIA DEL MAR', NULL, 1),
(618, 'OSTENDE', NULL, 1),
(619, 'MAR DE AJO', NULL, 1),
(620, 'VILLA MARIA', NULL, 5),
(621, 'VILLA ALLENDE', NULL, 5),
(622, 'VILLA ELISA', NULL, 7),
(623, 'VILLA SAN JOSE', NULL, 7),
(624, 'PUERTO ESPERANZA', NULL, 13),
(625, 'VILLA UNION', NULL, 11),
(626, 'VIEDMA', NULL, 15),
(627, 'TRELEW', NULL, 4),
(628, 'ALTA GRACIA', NULL, 5),
(629, 'SANTA ROSA', NULL, 10),
(630, 'VILLA KRAUSE', NULL, 17),
(631, 'GENERAL PICO', NULL, 10),
(632, 'PALMIRA', NULL, 12),
(633, 'SAN MARTIN', NULL, 12),
(634, 'JOSÉ LEON SUAREZ', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientobanco`
--

CREATE TABLE IF NOT EXISTS `movimientobanco` (
  `idmovimientobanco` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` date NOT NULL,
  `debeohaber` tinyint(1) NOT NULL,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `numerooperacion` bigint(20) DEFAULT NULL,
  `ctabancaria_idctabancaria` int(11) NOT NULL,
  PRIMARY KEY (`idmovimientobanco`),
  KEY `fk_movimientobanco_ctabancaria1_idx` (`ctabancaria_idctabancaria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientocaja`
--

CREATE TABLE IF NOT EXISTS `movimientocaja` (
  `idmovimientocaja` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `debeohaber` tinyint(1) NOT NULL,
  `debe` double DEFAULT NULL,
  `haber` double DEFAULT NULL,
  `id_de_trabajo` int(11) DEFAULT NULL,
  `caja_idcaja` int(11) NOT NULL,
  PRIMARY KEY (`idmovimientocaja`),
  KEY `idmovimientocaja` (`idmovimientocaja`),
  KEY `fk_movimientocaja_caja1_idx` (`caja_idcaja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordendepago`
--

CREATE TABLE IF NOT EXISTS `ordendepago` (
  `idordendepago` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `descripcionordendepago` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `importe` double DEFAULT NULL,
  `ctacteprov_idctacteprov` int(11) NOT NULL,
  `ordendepagocol` varchar(45) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`idordendepago`),
  KEY `fk_ordendepago_ctacteprov1_idx` (`ctacteprov_idctacteprov`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pais`
--

CREATE TABLE IF NOT EXISTS `pais` (
  `idpais` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idpais`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `pais`
--

INSERT INTO `pais` (`idpais`, `nombre`) VALUES
(2, 'Argentina');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE IF NOT EXISTS `proveedor` (
  `idproveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `cuit` varchar(13) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombrecontacto` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `web` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `localidad_idlocalidad` int(11) NOT NULL,
  `tipocontribuyente_idtipocontribuyente` int(11) NOT NULL,
  PRIMARY KEY (`idproveedor`),
  KEY `fk_proveedor_localidad1_idx` (`localidad_idlocalidad`),
  KEY `fk_proveedor_tipocontribuyente1_idx` (`tipocontribuyente_idtipocontribuyente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincia`
--

CREATE TABLE IF NOT EXISTS `provincia` (
  `idprovincia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 NOT NULL,
  `pais_idpais` int(11) NOT NULL,
  PRIMARY KEY (`idprovincia`),
  KEY `fk_provincia_pais1_idx` (`pais_idpais`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=24 ;

--
-- Volcado de datos para la tabla `provincia`
--

INSERT INTO `provincia` (`idprovincia`, `nombre`, `pais_idpais`) VALUES
(1, 'BUENOS AIRES', 2),
(2, 'CATAMARCA', 2),
(3, 'CHACO', 2),
(4, 'CHUBUT', 2),
(5, 'CORDOBA', 2),
(6, 'CORRIENTES', 2),
(7, 'ENTRE RIOS', 2),
(8, 'FORMOSA', 2),
(9, 'JUJUY', 2),
(10, 'LA PAMPA', 2),
(11, 'LA RIOJA', 2),
(12, 'MENDOZA', 2),
(13, 'MISIONES', 2),
(14, 'NEUQUEN', 2),
(15, 'RIO NEGRO', 2),
(16, 'SALTA', 2),
(17, 'SAN JUAN', 2),
(18, 'SAN LUIS', 2),
(19, 'SANTA CRUZ', 2),
(20, 'SANTA FE', 2),
(21, 'SANTIAGO DEL ESTERO', 2),
(22, 'TIERRA DEL FUEGO', 2),
(23, 'TUCUMAN', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subcuenta`
--

CREATE TABLE IF NOT EXISTS `subcuenta` (
  `idsubcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `codigosubcta` varchar(45) CHARACTER SET utf8 NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `cuenta_idcuenta` int(11) NOT NULL,
  `tipocuenta_idtipocuenta` int(11) NOT NULL,
  `asentable` tinyint(1) NOT NULL,
  PRIMARY KEY (`idsubcuenta`),
  KEY `fk_subcuenta_cuenta1_idx` (`cuenta_idcuenta`),
  KEY `fk_subcuenta_tipocuenta1_idx` (`tipocuenta_idtipocuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sueldo`
--

CREATE TABLE IF NOT EXISTS `sueldo` (
  `idsueldo` int(11) NOT NULL AUTO_INCREMENT,
  `importe` double NOT NULL,
  `comentario` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `created` date NOT NULL,
  `gratificacion` double DEFAULT NULL,
  `noremunerativo` double DEFAULT NULL,
  `art931` double DEFAULT NULL,
  `empleado_idempleado` int(11) NOT NULL,
  PRIMARY KEY (`idsueldo`),
  KEY `fk_sueldo_empleado1_idx` (`empleado_idempleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipocontribuyente`
--

CREATE TABLE IF NOT EXISTS `tipocontribuyente` (
  `idtipocontribuyente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `iva` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idtipocontribuyente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoctabancaria`
--

CREATE TABLE IF NOT EXISTS `tipoctabancaria` (
  `idtipoctabancaria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`idtipoctabancaria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipocuenta`
--

CREATE TABLE IF NOT EXISTS `tipocuenta` (
  `idtipocuenta` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `codigocuenta` varchar(45) CHARACTER SET utf8 NOT NULL,
  `tipogral_idtipogral` int(11) NOT NULL,
  PRIMARY KEY (`idtipocuenta`),
  KEY `fk_tipocuenta_tipogral1_idx` (`tipogral_idtipogral`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `tipocuenta`
--

INSERT INTO `tipocuenta` (`idtipocuenta`, `nombre`, `codigocuenta`, `tipogral_idtipogral`) VALUES
(2, 'Activos Corrientes', '110000', 1),
(3, 'Activos No Corrientes', '120000', 1),
(4, 'Pasivos Corrientes', '210000', 2),
(5, 'Otros pasivos', '215000', 2),
(6, 'Pasivos No corrientes', '220000', 2),
(7, 'Patrimonio Neto', '300000', 5),
(8, 'ER-Erogaciones', '400000', 3),
(9, 'ER-Ingresos', '500000', 3),
(10, 'Inflación - Deflación', '600000', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipogral`
--

CREATE TABLE IF NOT EXISTS `tipogral` (
  `idtipogral` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`idtipogral`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `tipogral`
--

INSERT INTO `tipogral` (`idtipogral`, `nombre`) VALUES
(1, 'Activo'),
(2, 'Pasivo'),
(3, 'Estado de resultado'),
(4, 'Inflación - Deflación '),
(5, 'Patrimonio Neto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `lastname` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `username` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`iduser`, `firstname`, `lastname`, `username`, `password`, `email`) VALUES
(1, 'admin', 'admin', 'admin', 'e10adc3949ba59abbe56e057f20f883e', NULL);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asiento`
--
ALTER TABLE `asiento`
  ADD CONSTRAINT `fk_asiento_cuenta2` FOREIGN KEY (`cuenta_idcuenta`) REFERENCES `cuenta` (`idcuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asiento_subcuenta1` FOREIGN KEY (`subcuenta_idsubcuenta`) REFERENCES `subcuenta` (`idsubcuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `authassignment`
--
ALTER TABLE `authassignment`
  ADD CONSTRAINT `authassignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `authitemchild`
--
ALTER TABLE `authitemchild`
  ADD CONSTRAINT `authitemchild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `authitemchild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `authitem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `banco`
--
ALTER TABLE `banco`
  ADD CONSTRAINT `fk_banco_localidad1` FOREIGN KEY (`localidad_idlocalidad`) REFERENCES `localidad` (`idlocalidad`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `caja`
--
ALTER TABLE `caja`
  ADD CONSTRAINT `fk_caja_cuenta1` FOREIGN KEY (`cuenta_idcuenta`) REFERENCES `cuenta` (`idcuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cheque`
--
ALTER TABLE `cheque`
  ADD CONSTRAINT `fk_cheque_banco1` FOREIGN KEY (`banco_idBanco`) REFERENCES `banco` (`idBanco`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cheque_cliente1` FOREIGN KEY (`cliente_idcliente`) REFERENCES `cliente` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cheque_proveedor1` FOREIGN KEY (`proveedor_idproveedor`) REFERENCES `proveedor` (`idproveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `fk_cliente_localidad1` FOREIGN KEY (`localidad_idlocalidad`) REFERENCES `localidad` (`idlocalidad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cliente_tipocontribuyente1` FOREIGN KEY (`tipocontribuyente_idtipocontribuyente`) REFERENCES `tipocontribuyente` (`idtipocontribuyente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cobranza`
--
ALTER TABLE `cobranza`
  ADD CONSTRAINT `fk_cobranza_ctactecliente1` FOREIGN KEY (`ctactecliente_idctactecliente`) REFERENCES `ctactecliente` (`idctactecliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ctabancaria`
--
ALTER TABLE `ctabancaria`
  ADD CONSTRAINT `fk_ctabancaria_banco1` FOREIGN KEY (`banco_idBanco`) REFERENCES `banco` (`idBanco`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ctabancaria_tipoctabancaria1` FOREIGN KEY (`tipoctabancaria_idtipoctabancaria`) REFERENCES `tipoctabancaria` (`idtipoctabancaria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ctactecliente`
--
ALTER TABLE `ctactecliente`
  ADD CONSTRAINT `fk_ctactecliente_cliente1` FOREIGN KEY (`cliente_idcliente`) REFERENCES `cliente` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ctacteprov`
--
ALTER TABLE `ctacteprov`
  ADD CONSTRAINT `fk_ctacteprov_proveedor1` FOREIGN KEY (`proveedor_idproveedor`) REFERENCES `proveedor` (`idproveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cuenta`
--
ALTER TABLE `cuenta`
  ADD CONSTRAINT `fk_cuenta_tipocuenta1` FOREIGN KEY (`tipocuenta_idtipocuenta`) REFERENCES `tipocuenta` (`idtipocuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `detallecobranza`
--
ALTER TABLE `detallecobranza`
  ADD CONSTRAINT `fk_detallecobranza_cheque1` FOREIGN KEY (`cheque_idcheque`) REFERENCES `cheque` (`idcheque`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_detallecobranza_cobranza1` FOREIGN KEY (`cobranza_idcobranza`) REFERENCES `cobranza` (`idcobranza`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detallecobranza_movimientobanco1` FOREIGN KEY (`movimientobanco_idmovimientobanco`) REFERENCES `movimientobanco` (`idmovimientobanco`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_detallecobranza_movimientocaja1` FOREIGN KEY (`movimientocaja_idmovimientocaja`) REFERENCES `movimientocaja` (`idmovimientocaja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `detallectactecliente`
--
ALTER TABLE `detallectactecliente`
  ADD CONSTRAINT `fk_detallectactecliente_ctactecliente1` FOREIGN KEY (`ctactecliente_idctactecliente`) REFERENCES `ctactecliente` (`idctactecliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detallectactecliente_factura1` FOREIGN KEY (`factura_idfactura`) REFERENCES `factura` (`idfactura`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `detallectacteprov`
--
ALTER TABLE `detallectacteprov`
  ADD CONSTRAINT `fk_detallectacteprov_ctacteprov1` FOREIGN KEY (`ctacteprov_idctacteprov`) REFERENCES `ctacteprov` (`idctacteprov`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detallefactura`
--
ALTER TABLE `detallefactura`
  ADD CONSTRAINT `fk_detallefactura_factura1` FOREIGN KEY (`factura_idfactura`) REFERENCES `factura` (`idfactura`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `detalleordendepago`
--
ALTER TABLE `detalleordendepago`
  ADD CONSTRAINT `fk_detalleordendepago_cheque1` FOREIGN KEY (`cheque_idcheque`) REFERENCES `cheque` (`idcheque`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_detalleordendepago_movimientobanco1` FOREIGN KEY (`movimientobanco_idmovimientobanco`) REFERENCES `movimientobanco` (`idmovimientobanco`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_detalleordendepago_movimientocaja1` FOREIGN KEY (`movimientocaja_idmovimientocaja`) REFERENCES `movimientocaja` (`idmovimientocaja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_detalleordendepago_ordendepago1` FOREIGN KEY (`ordendepago_idordendepago`) REFERENCES `ordendepago` (`idordendepago`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD CONSTRAINT `fk_empleado_area1` FOREIGN KEY (`area_idarea`) REFERENCES `area` (`idarea`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD CONSTRAINT `fk_empresa_localidad1` FOREIGN KEY (`localidad_idlocalidad`) REFERENCES `localidad` (`idlocalidad`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `fk_factura_cuenta1` FOREIGN KEY (`cuenta_idcuenta`) REFERENCES `cuenta` (`idcuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_factura_subcuenta1` FOREIGN KEY (`subcuenta_idsubcuenta`) REFERENCES `subcuenta` (`idsubcuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ivamovimiento`
--
ALTER TABLE `ivamovimiento`
  ADD CONSTRAINT `fk_ivamovimiento_cliente1` FOREIGN KEY (`cliente_idcliente`) REFERENCES `cliente` (`idcliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ivamovimiento_proveedor1` FOREIGN KEY (`proveedor_idproveedor`) REFERENCES `proveedor` (`idproveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `localidad`
--
ALTER TABLE `localidad`
  ADD CONSTRAINT `fk_localidad_provincia1` FOREIGN KEY (`provincia_idprovincia`) REFERENCES `provincia` (`idprovincia`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `movimientobanco`
--
ALTER TABLE `movimientobanco`
  ADD CONSTRAINT `fk_movimientobanco_ctabancaria1` FOREIGN KEY (`ctabancaria_idctabancaria`) REFERENCES `ctabancaria` (`idctabancaria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `movimientocaja`
--
ALTER TABLE `movimientocaja`
  ADD CONSTRAINT `fk_movimientocaja_caja1` FOREIGN KEY (`caja_idcaja`) REFERENCES `caja` (`idcaja`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ordendepago`
--
ALTER TABLE `ordendepago`
  ADD CONSTRAINT `fk_ordendepago_ctacteprov1` FOREIGN KEY (`ctacteprov_idctacteprov`) REFERENCES `ctacteprov` (`idctacteprov`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD CONSTRAINT `fk_proveedor_localidad1` FOREIGN KEY (`localidad_idlocalidad`) REFERENCES `localidad` (`idlocalidad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_proveedor_tipocontribuyente1` FOREIGN KEY (`tipocontribuyente_idtipocontribuyente`) REFERENCES `tipocontribuyente` (`idtipocontribuyente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `provincia`
--
ALTER TABLE `provincia`
  ADD CONSTRAINT `fk_provincia_pais1` FOREIGN KEY (`pais_idpais`) REFERENCES `pais` (`idpais`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `subcuenta`
--
ALTER TABLE `subcuenta`
  ADD CONSTRAINT `fk_subcuenta_cuenta1` FOREIGN KEY (`cuenta_idcuenta`) REFERENCES `cuenta` (`idcuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_subcuenta_tipocuenta1` FOREIGN KEY (`tipocuenta_idtipocuenta`) REFERENCES `tipocuenta` (`idtipocuenta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `sueldo`
--
ALTER TABLE `sueldo`
  ADD CONSTRAINT `fk_sueldo_empleado1` FOREIGN KEY (`empleado_idempleado`) REFERENCES `empleado` (`idempleado`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tipocuenta`
--
ALTER TABLE `tipocuenta`
  ADD CONSTRAINT `fk_tipocuenta_tipogral1` FOREIGN KEY (`tipogral_idtipogral`) REFERENCES `tipogral` (`idtipogral`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
